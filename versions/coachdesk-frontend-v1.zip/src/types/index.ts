export interface ApiResponse<T = unknown> {
  status: boolean;
  message?: string;
  data: T;
  pagination?: Pagination;
  errors?: Record<string, string>;
}

export interface Pagination {
  page: number;
  limit: number;
  total: number;
  totalPages: number;
}

export interface User {
  id: string | number;
  name: string;
  email: string;
  tenant_id?: number | null;
  branch_id?: number | null;
  role?: string;
  roles?: string[];
  permissions?: string[];
  is_super_admin?: boolean | number;
  isSuperAdmin?: boolean;
  avatar?: string;
}

export interface AuthTokens {
  access_token: string;
  refresh_token: string;
  user: User;
}

export interface LoginPayload {
  email: string;
  password: string;
}

export interface Student {
  id: number;
  public_id: string;
  student_code: string;
  name: string;
  email?: string;
  phone?: string;
  gender?: 'male' | 'female' | 'other';
  status: 'active' | 'inactive' | 'completed' | 'cancelled';
  admission_date?: string;
  branch_name?: string;
  branch_code?: string;
}

export interface Batch {
  id: string | number;
  public_id: string;
  tenant_id?: string | number;
  branch_id?: string | number;
  course_id?: string | number;
  academic_session_id?: string | number;
  batch_name: string;
  name?: string;
  batch_code: string;
  code?: string;
  capacity: string | number;
  start_date?: string | null;
  end_date?: string | null;
  timing_start?: string | null;
  timing_end?: string | null;
  status: 'running' | 'upcoming' | 'completed' | 'cancelled' | string;
  created_at?: string;
  updated_at?: string;
  deleted_at?: string | null;
  course_name?: string;
  course_code?: string;
}

export interface BatchListParams {
  page?: number;
  perPage?: number;
  limit?: number;
  search?: string;
  status?: string;
  course_id?: string | number;
}

export interface Teacher {
  id: string | number;
  public_id: string;
  tenant_id?: string | number | null;
  branch_id?: string | number | null;
  name: string;
  email?: string | null;
  phone?: string | null;
  subject?: string | null;
  qualification?: string | null;
  experience_years?: string | number | null;
  status: 'active' | 'inactive' | string;
  joining_date?: string | null;
  created_at?: string;
  updated_at?: string;
  deleted_at?: string | null;
  branch_name?: string;
}

export interface TeacherListParams {
  page?: number;
  perPage?: number;
  limit?: number;
  search?: string;
  status?: string;
  subject?: string;
}

export interface Course {
  id: string | number;
  public_id: string;
  tenant_id?: string | number | null;
  branch_id?: string | number | null;
  course_name: string;
  course_code: string;
  name?: string;
  code?: string;
  duration?: string | number | null;
  fees?: string | number | null;
  description?: string | null;
  status: 'active' | 'inactive' | string;
  created_at?: string;
  updated_at?: string;
  deleted_at?: string | null;
}

export interface CourseListParams {
  page?: number;
  perPage?: number;
  limit?: number;
  search?: string;
  status?: string;
}

export interface DashboardStats {
  students?: {
    total: number;
    active: number;
    new_this_month: number;
  };
  teachers?: { total: number };
  batches?: {
    total: number;
    running: number;
    upcoming: number;
    completed: number;
  };
  attendance_today?: {
    present: number;
    absent: number;
    late: number;
    total_marked: number;
  };
  fees?: {
    collected_today: number;
    collected_month: number;
    outstanding: number;
    defaulters_count: number;
  };
  recent_payments?: Array<{
    public_id: string;
    receipt_number: string;
    amount: string;
    method: string;
    payment_date: string;
    student_name: string;
  }>;
  upcoming_exams?: Array<{
    public_id: string;
    exam_name: string;
    exam_date: string;
    batch_name: string;
  }>;
  monthly_collection?: Array<{ month: string; total: number }>;
  admissions_chart?: Array<{ month: string; count: number }>;
}